package com.cognizant.service;

import java.util.ArrayList;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;


import com.cognizant.model.Loan;

@Service
public class LoanService {
	
	ArrayList<Loan> loanList= new ArrayList<Loan>();
	public LoanService()
	{
		ApplicationContext con= new ClassPathXmlApplicationContext("loan.xml");
		loanList= (ArrayList<Loan>) con.getBean("loanList");
	}
	
	public ArrayList<Loan> getLoans(String number) {
		return (ArrayList<Loan>) loanList.stream().filter(t -> t.getNumber().equalsIgnoreCase(number))
				.collect(Collectors.toList());
	}
}
