package com.cognizant.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Account;
import com.cognizant.service.AccountService;

@RestController
public class AccountController {
	// ApplicationContext con= new
	// ClassPathXmlApplicationContext("account.xml");
	@Autowired
	private AccountService service;

	@GetMapping("/accounts/{number}")
	public ArrayList<Account> getAccounts(@PathVariable String number) {
		return service.getAccounts(number);
	}
}
