package com.cognizant.service;

import java.util.ArrayList;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.model.Account;

@Service
public class AccountService {

	ArrayList<Account> accList = new ArrayList<Account>();

	public AccountService() {
		ApplicationContext con = new ClassPathXmlApplicationContext("account.xml");
		accList = (ArrayList<Account>) con.getBean("accountList");
	}

	public ArrayList<Account> getAccounts(String number) {
		return (ArrayList<Account>) accList.stream().filter(t -> t.getNumber().equalsIgnoreCase(number))
				.collect(Collectors.toList());
	}
}
