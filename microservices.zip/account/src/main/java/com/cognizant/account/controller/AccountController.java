package com.cognizant.account.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.account.model.Account;

@RestController
public class AccountController {

	@GetMapping("/accounts/{number}")
	public ResponseEntity<Object> details(@PathVariable String number)
	{
		Account a=new Account(number,123456,"savings");
		return new ResponseEntity<>(a,HttpStatus.OK);
	}
}
