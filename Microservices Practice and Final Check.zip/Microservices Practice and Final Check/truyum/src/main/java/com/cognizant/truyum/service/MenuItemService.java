package com.cognizant.truyum.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.truyum.TruyumApplication;
import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;

@Service
public class MenuItemService {

	private static final Logger LOGGER = LoggerFactory.getLogger(TruyumApplication.class);
	
	@Autowired()
	MenuItemDaoCollectionImpl menuItemDao;
	
	@Transactional
	public List<MenuItem> getMenuItemListCustomer() {
		LOGGER.info("MENULIST-CUSTOMER-SERVICE-START");
		List<MenuItem> menuItemList = menuItemDao.getMenuItemListCustomer();
		LOGGER.info("MENULIST-CUSTOMER-SERVICE-END");
		return menuItemList;
	}

	public MenuItem getMenuItem(long id) {
		LOGGER.info("EDITMENU-SERVICE-START");
		MenuItem menuItem = menuItemDao.getMenuItem(id);
		LOGGER.info("EDITMENU-SERVICE-END");
		return menuItem;
	}
	
	public void modifyMenuItem(long id, MenuItem menuItem) {
		LOGGER.info("UPDATEMENU-SERVICE-START");
		menuItemDao.modifyMenuItem(id, menuItem);
		LOGGER.info("UPDATEMENU-SERVICE-END");
	}
}
