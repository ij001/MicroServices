package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.TruyumApplication;
import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao{

	private ApplicationContext context = new ClassPathXmlApplicationContext("truyum.xml");
	
	private ArrayList<MenuItem> menuItemList;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TruyumApplication.class);
	
	@SuppressWarnings("unchecked")
	public List<MenuItem> getMenuItemListCustomer(){
		LOGGER.info("MENULIST-CUSTOMER-DAO-START");
		this.menuItemList = (ArrayList<MenuItem>) context.getBean("menuItemList");
		LOGGER.info("MENULIST-CUSTOMER-DAO-END");
		return menuItemList;
	}

	public MenuItem getMenuItem(long id) {
		LOGGER.info("EDITMENU-DAO-START");
		MenuItem menuItem = menuItemList.stream()
				.filter(menuItems -> menuItems.getId() == id ).findFirst().get();
		LOGGER.info("EDITMENU-DAO-END");
		return menuItem;
	}

	public void modifyMenuItem(long id,MenuItem menuItem) {
		LOGGER.info("UPDATEMENU-DAO-START");
		for(int i = 0;i < menuItemList.size();i++) {
			if(menuItemList.get(i).getId() == id) {
				menuItemList.set(i, menuItem);
			}
		}
		LOGGER.info("UPDATEMENU-DAO-END");
	}
}
