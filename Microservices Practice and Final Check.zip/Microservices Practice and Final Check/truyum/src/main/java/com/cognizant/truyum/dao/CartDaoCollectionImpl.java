package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.MenuItem;

@Component
public class CartDaoCollectionImpl implements CartDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartDaoCollectionImpl.class);
	
	@Autowired
	private MenuItemDao menuItemDao;
	
	private Map<String, List<MenuItem>> cartItemsMap = new HashMap<String, List<MenuItem>>();

	@Override
	public void addCartItem(String userId, long menuItemId) {
		MenuItem menuItem = menuItemDao.getMenuItem(menuItemId);
		List<MenuItem> menuItemList = cartItemsMap.get(userId);
		if(menuItemList == null) {
			menuItemList = new ArrayList<MenuItem>();
			menuItemList.add(menuItem);
		}
		else {
			if(!menuItemList.contains(menuItem))
				menuItemList.add(menuItem);
		}
		cartItemsMap.put(userId, menuItemList);
		for(Map.Entry<String, List<MenuItem>> entry : cartItemsMap.entrySet()) {
			for(MenuItem mI : entry.getValue())
				LOGGER.debug(entry.getKey()+" "+mI.toString());
		}
	}

	@Override
	public List<MenuItem> getAllCartItems(String userId) {
		List<MenuItem> cartItemsUser = cartItemsMap.get(userId);
		return cartItemsUser;
	}

	@Override
	public void deleteCartItems(String userId, long menuItemId) {
		List<MenuItem> currUserItems = cartItemsMap.get(userId);
		for(MenuItem menuItemDelete : currUserItems) {
			if(menuItemDelete.getId() == menuItemId)
				cartItemsMap.get(userId).remove(menuItemDelete);
		}
			
		for(Map.Entry<String, List<MenuItem>> entry : cartItemsMap.entrySet()) {
			for(MenuItem mI : entry.getValue())
				LOGGER.debug(entry.getKey()+" "+mI.toString());
		}
	}
}
