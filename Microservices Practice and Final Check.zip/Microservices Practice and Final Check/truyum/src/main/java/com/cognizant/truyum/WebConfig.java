package com.cognizant.truyum;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.cognizant.truyum")
public class WebConfig {

}
