package com.cognizant.truyum.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.TruyumApplication;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

@RestController
@RequestMapping(value = "/menu-items", produces = {"application/json"})
public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(TruyumApplication.class);
	
	@Autowired
	MenuItemService menuItemService;
	
	@GetMapping("/")
	public List<MenuItem> getAllMenuItems() {
		LOGGER.info("MENULIST-CUSTOMER-CONTROLLER-START");
		List<MenuItem> menuItemList = menuItemService.getMenuItemListCustomer();
		LOGGER.debug("he");
		LOGGER.info("MENULIST-CUSTOMER-CONTROLLER-END");
		return menuItemList;
	}
	
	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable long id) {
		LOGGER.info("EDITMENU-CONTROLLER-START");
		MenuItem menuItem = menuItemService.getMenuItem(id);
		LOGGER.info("EDITMENU-CONTROLLER-END");
		return menuItem;
	}
	
	@PutMapping("/update/{id}")
	public void modifyMenuItem(@PathVariable long id, @RequestBody MenuItem menuItem) {
		LOGGER.info("UPDATEMENU-CONTROLLER-START");
		menuItemService.modifyMenuItem(id, menuItem);
		LOGGER.info("UPDATEMENU-CONTROLLER-END");
	}
}
