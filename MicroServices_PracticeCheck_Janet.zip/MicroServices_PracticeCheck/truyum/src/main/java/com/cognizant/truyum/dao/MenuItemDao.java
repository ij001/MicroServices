package com.cognizant.truyum.dao;

public interface MenuItemDao {

}
