package com.cognizant.truyum.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dao.MenuItemDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;

@Service
public class MenuItemService {
	
	@Autowired
	private MenuItemDaoCollectionImpl dao;
	public ArrayList<MenuItem> getMenuItemListCustomer()
	{
		return dao.getMenuItemListCustomer();
	}
	
	public MenuItem getMenuItem(String id)
	{
		return dao.getMenuItem(id);
	}
	
	public void modifyMenuItem(MenuItem menuItem)
	{
		dao.modifyMenuItem(menuItem);
	}
}
