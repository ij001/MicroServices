package com.cognizant.truyum.dao;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao {
	
	private ArrayList<MenuItem> menuItemList=new ArrayList<MenuItem>();
	public MenuItemDaoCollectionImpl()
	{
		ApplicationContext con= new ClassPathXmlApplicationContext("truyum.xml");
		menuItemList= (ArrayList<MenuItem>) con.getBean("menuItemList");
	}
	public ArrayList<MenuItem> getMenuItemListCustomer()
	{
		return menuItemList;
	}
	public MenuItem getMenuItem(String id)
	{
		for(int i=0;i<menuItemList.size();i++)
		{
			MenuItem obj=menuItemList.get(i);
			if(obj.getId().equals(id))
				return obj;
		}
		return null;
	}
	public void modifyMenuItem(MenuItem menuItem)
	{
		for(int i=0;i<menuItemList.size();i++)
		{
			MenuItem obj=menuItemList.get(i);
			if(obj.getId().equals(menuItem.getId()))
				menuItemList.set(i, menuItem);
		}
		
	}
}