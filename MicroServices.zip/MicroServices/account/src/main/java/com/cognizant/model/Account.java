package com.cognizant.model;

public class Account {
private String number;
private String type;
private float balance;
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}
@Override
public String toString() {
	return "Account [number=" + number + ", type=" + type + ", balance=" + balance + "]";
}

}
