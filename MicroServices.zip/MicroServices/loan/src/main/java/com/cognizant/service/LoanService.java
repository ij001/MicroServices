package com.cognizant.service;

import org.springframework.stereotype.Service;

import com.cognizant.model.Loan;

@Service
public class LoanService {
Loan l=new Loan();
	public Loan getLoan(String number)
{
		l.setNumber("H00987987972342");
		l.setType("car");
		l.setLoan(400000);
		l.setEmi(3258);
		l.setTenure(18);
		if(l.getNumber().equals(number))
			return l;
		else
			return null;
	
}
}
