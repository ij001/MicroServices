package com.finalcheck.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.finalcheck.model.Movie;
import com.finalcheck.service.MovieService;

@RestController
public class MovieController {
	@Autowired
	MovieService service;
	
	@GetMapping("/admin/movie")
	public ArrayList<Movie> getAllMovies()
	{
		return service.getAllMovies();
	}
	
	@PostMapping("/admin/movie")
	public void editMovie(@RequestBody Movie movie)
	{
		service.editMovie(movie);
	}
	@GetMapping("/customer/movie")
	public ArrayList<Movie> getCustomerMovies()
	{
		return service.getCustomerMovies();
	}
	@PutMapping("/customer/movie/{title}")
	public void makeMovieFavorite(@PathVariable String title)
	{
		service.makeMovieFavorite(title);
	}
	@GetMapping("/customer/movie/favorite")
	public Map<ArrayList<String>,Long> getAllFavoriteMovies()
	{
		Map<ArrayList<String>,Long> map= new HashMap<ArrayList<String>,Long>();
		ArrayList<String> list=new ArrayList<String>();
		list=service.getAllFavoriteMovies();
		map.put(list, service.favoriteCount());
		return map;
	}
	@DeleteMapping("/customer/movie/{title}")
	public void deleteMovie(@PathVariable String title)
	{
		service.deleteMovie(title);
	}
}
