package com.cognizant.moviecruiser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.service.MovieService;
@RestController
public class MovieController {
	@Autowired
	private MovieService movieService;
	@GetMapping("/movie/{id}")
	public Movie getMenuItem(@PathVariable int id)
	{
		return movieService.getMenuItem(id);
	}
	@PutMapping("/movieitem/{id}")
	public void modifyMenuItem(@RequestBody Movie menu,@PathVariable int id)
	{
		movieService.modifyMenuItem(id, menu);
	}

}
