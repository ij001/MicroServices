package com.cognizant.moviecruiser.model;

import java.util.Date;

public class Movie {
	private int id;
	private String name;
	private float hitrate;
	private boolean active;
	private Date dateOfLaunch;
	private String genre;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getHitrate() {
		return hitrate;
	}
	public void setHitrate(float hitrate) {
		this.hitrate = hitrate;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public Date getDateOfLaunch() {
		return dateOfLaunch;
	}
	public void setDateOfLaunch(Date dateOfLaunch) {
		this.dateOfLaunch = dateOfLaunch;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", name=" + name + ", hitrate=" + hitrate + ", active=" + active + ", dateOfLaunch="
				+ dateOfLaunch + ", genre=" + genre + "]";
	}
	

}
