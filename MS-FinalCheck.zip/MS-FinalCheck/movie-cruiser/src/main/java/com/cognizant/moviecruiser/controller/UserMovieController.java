package com.cognizant.moviecruiser.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.moviecruiser.model.Movie;
import com.cognizant.moviecruiser.service.UserMovieService;

@RestController
public class UserMovieController {
	@Autowired
	private UserMovieService usermovieService;
@PostMapping("/{userid}/{menuItemId}")
public void addCartItem(@PathVariable String userid,@PathVariable int menuItemId)
{
	usermovieService.addCartItem(userid, menuItemId);
}
@GetMapping("/carts/{userid}")
public ArrayList<Movie> getAllCartItem(@PathVariable String userid)
{
	return usermovieService.getAllCartItems(userid);
}
@DeleteMapping("/{userid}/{menuItemId}")
public void deleteAllCartItem(@PathVariable String userid,@PathVariable int menuItemId)
{
	usermovieService.deleteCartItem(userid, menuItemId);
}

}
