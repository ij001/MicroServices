package com.cognizant.truYum1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cognizant.truYum1")
@EnableDiscoveryClient
public class TruYum1Application {

	public static void main(String[] args) {
		SpringApplication.run(TruYum1Application.class, args);
	}

}
