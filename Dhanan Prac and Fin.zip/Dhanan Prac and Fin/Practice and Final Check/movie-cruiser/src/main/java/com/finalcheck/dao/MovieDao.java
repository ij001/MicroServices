package com.finalcheck.dao;

import java.util.ArrayList;
import java.util.stream.Collectors;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import com.finalcheck.model.Movie;

@Component
public class MovieDao {
	ArrayList<Movie> movieList= new ArrayList<Movie>();
	MovieDao()
	{
		ApplicationContext con= new ClassPathXmlApplicationContext("movie.xml");
		movieList= (ArrayList<Movie>)con.getBean("movieList");
	}
	public ArrayList<Movie> getAllMovies()
	{
		return movieList;
	}
	/*public void addMovie(Movie movie)
	{
		movieList.add(movie);
	}*/
	public void editMovie(Movie movie)
	{
		for(int i=0;i<movieList.size();i++)
		{
			Movie obj=movieList.get(i);
			if(obj.getTitle().equals(movie.getTitle()))
				movieList.set(i, movie);
		}
	}
	public ArrayList<Movie> getCustomerMovies()
	{
		return (ArrayList<Movie>) movieList.stream().filter(m->m.isActive()==true).collect(Collectors.toList());
	}
	public void makeMovieFavorite(String title)
	{
		for(Movie movie:movieList)
		{
			if(movie.getTitle().equalsIgnoreCase(title))
				{
					movie.setFavorite("yes");
				}
		}
	}
	public ArrayList<String> getAllFavoriteMovies()
	{
		ArrayList<String> li=new ArrayList<String>();
		for(Movie movie:movieList)
		{
			if(movie.getFavorite().equalsIgnoreCase("yes"))
			{
				li.add(movie.getTitle());
			}
		}
		return li;
	}
	public long favoriteCount()
	{
		return movieList.stream().filter(m->m.getFavorite().equalsIgnoreCase("yes")).count();
	}
	public void deleteMovie(String title)
	{
		for(int i=0;i<movieList.size();i++)
		{
			if(movieList.get(i).getTitle().equalsIgnoreCase(title))
			{
				movieList.remove(i);
			}
		}
	}
}
