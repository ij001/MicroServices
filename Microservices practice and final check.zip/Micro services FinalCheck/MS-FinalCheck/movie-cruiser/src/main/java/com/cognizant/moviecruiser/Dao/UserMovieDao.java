package com.cognizant.moviecruiser.Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.moviecruiser.model.Movie;
@Component
public class UserMovieDao {
	@Autowired
	private MovieDao movieDao;
	private Map<String,Movie> movieMap=new HashMap<String,Movie>(); 
	ArrayList<Movie> movielist=new ArrayList<Movie>();
	public UserMovieDao()
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("movielistuser.xml");
		this.movieMap=(Map<String,Movie>)context.getBean("moviemap");
	}
public void addCartItem(String userid,int menuid)
{
	Movie menu=movieDao.getMenuItem(menuid);
	movieMap.put(userid, menu);
}
public ArrayList<Movie> getAllCartItems(String userid)
{
	
	for(Map.Entry cmap:movieMap.entrySet())
	{
		if(cmap.getKey().equals(userid))
		{
			this.movielist.add((Movie) cmap.getValue()); 
		}
	}
	System.out.println(movielist);
	return this.movielist;
}
public void deleteCartItem(String userid,int menuid)
{
	for(Map.Entry cmap:movieMap.entrySet())
	{
		int f=0;
		if(cmap.getKey().equals(userid))
		{
			Movie mi=(Movie) cmap.getValue(); 
			if(mi.getId()==menuid)
			{
				movieMap.replace(userid, mi,null);
				f=1;
				break;
			}
			
		if(f==1)
			break;
		}

	}
	System.out.println(movieMap);
}

}
