package com.cognizant.moviecruiser.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.Dao.UserMovieDao;
import com.cognizant.moviecruiser.model.Movie;


@Service
public class UserMovieService {
	@Autowired
	private UserMovieDao usermovieDao;
public void addCartItem(String user,int menu)
{
	usermovieDao.addCartItem(user, menu);
}
public ArrayList<Movie> getAllCartItems(String userid)
{
	return usermovieDao.getAllCartItems(userid);
}
public void deleteCartItem(String uid,int mid)
{
	usermovieDao.deleteCartItem(uid, mid);
}
}
