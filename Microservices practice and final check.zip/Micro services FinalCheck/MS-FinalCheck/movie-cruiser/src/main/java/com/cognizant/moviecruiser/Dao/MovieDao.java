package com.cognizant.moviecruiser.Dao;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.moviecruiser.model.Movie;

//import com.cognizant.truYum1.model.MenuItem;
@Component
public class MovieDao {
	private ArrayList<Movie> movieList=new ArrayList<Movie>();
	public MovieDao()
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("movie.xml");
		this.movieList=(ArrayList<Movie>)context.getBean("movieList");
	}
public Movie getMenuItem(int id)
{
	for(Movie m:movieList)
	{
		if(m.getId()==id)
			return m;
	}
	return null;
}
public void modifyMenuItem(int id,Movie m)
{
	for(int i=0;i<movieList.size();i++)
	{
		Movie menu=movieList.get(i);
		if(menu.getId()==id)
		{
			movieList.set(i, m);
		}
	}
}

}
