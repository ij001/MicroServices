package com.cognizant.moviecruiser.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.moviecruiser.Dao.MovieDao;
import com.cognizant.moviecruiser.model.Movie;
@Service
public class MovieService {
	@Autowired
	private MovieDao movieDao;
public Movie getMenuItem(int id) {
	return movieDao.getMenuItem(id);
}

public void modifyMenuItem(int id,Movie menu)
{
	movieDao.modifyMenuItem(id, menu);
}
}
