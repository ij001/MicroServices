package com.cognizant.truYum1.dao;

public class MenuItemDaoCollectionImpl {

}
