package com.cognizant.service;

import org.springframework.stereotype.Service;

import com.cognizant.model.Account;

@Service
public class AccountService {
	Account ac=new Account();
	public Account getAccount(String no) {
		
		ac.setNumber("00987987973432");
		ac.setType("savings");
		ac.setBalance(234343);
		if(ac.getNumber().equals(no))
			return ac;
		else
			return null;
	}
}
