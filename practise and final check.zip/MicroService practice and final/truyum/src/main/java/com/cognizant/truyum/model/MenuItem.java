package com.cognizant.truyum.model;

import lombok.Data;

public @Data class MenuItem {

	private long id;
	private String name,category;
	private float price;
	private boolean active,freeDelivery;
	private String dateOfLaunch;
}
