package com.cognizant.truyum.model;

import java.util.List;

import lombok.Data;

public @Data class Cart {

	private String userId;
	private List<MenuItem> menuItemList;
}
