package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import com.cognizant.truyum.model.MenuItem;

@Component
public class MenuItemDaoCollectionImpl implements MenuItemDao {

	private static List<MenuItem> menuItemList;
	private static final Logger LOGGER=LoggerFactory.getLogger(MenuItemDaoCollectionImpl.class);
	public MenuItemDaoCollectionImpl(List<MenuItem> menuItemList)
	{
		if(menuItemList.isEmpty()==true)
		{
			ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
			menuItemList=(ArrayList<MenuItem>)context.getBean("menulist");
		}
	}

	public MenuItemDaoCollectionImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<MenuItem> getMenuItemListAdmin() {
		return menuItemList;
	}

	@Override
	public List<MenuItem> getMenuItemListCustomer() {
		LOGGER.info("Start");
		ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
		menuItemList=(ArrayList<MenuItem>)context.getBean("menulist");
		for(int i=0;i<menuItemList.size();i++)
		{
			if(menuItemList.get(i).isActive()==false)
			{
				menuItemList.remove(i);
			}
		}
		return menuItemList;
	}

	@Override
	public void modifyMenuItem(MenuItem menuItem) {
		LOGGER.info("START");
		ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
		menuItemList=(ArrayList<MenuItem>)context.getBean("menulist");
		for(MenuItem item:menuItemList)
		{
			if(menuItem.getId()==item.getId())
			{
				int index=menuItemList.indexOf(item);
				menuItemList.set(index, menuItem);
				LOGGER.info("Modified");
			}
		}
	}

	@Override
	public MenuItem getMenuItem(long menuItemId) {
		MenuItem menu=new MenuItem();
		ApplicationContext context=new ClassPathXmlApplicationContext("truyum.xml");
		menuItemList=(ArrayList<MenuItem>)context.getBean("menulist");
		for(MenuItem menuItem:menuItemList)
		{
			if(menuItem.getId()==menuItemId)
			{
				return menuItem;
			}
		}
		return menu;
	}
}
