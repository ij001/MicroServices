package com.cognizant.truyum.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;

@Component
public class CartDaoCollectionImpl implements CartDao {

	private static final Logger LOGGER=LoggerFactory.getLogger(CartDaoCollectionImpl.class);
	private static HashMap<String,MenuItem> userCarts;
	private ArrayList<MenuItem> list=new ArrayList<MenuItem>();
	
	@Override
	public void addCartItem(String userId, long menuItemId) {
		ApplicationContext context=new ClassPathXmlApplicationContext("cart.xml");
		userCarts=(HashMap<String,MenuItem>) context.getBean("cartlist");
		MenuItemDaoCollectionImpl menuItem=new MenuItemDaoCollectionImpl();
		MenuItem item=menuItem.getMenuItem(menuItemId);
		LOGGER.info("START");
		for(Map.Entry cart:userCarts.entrySet())
		{
			if(cart.getKey().toString().equals(userId))
			{
				userCarts.put(userId, item);
			}
		}
	}

	@Override
	public List<MenuItem> getAllCartItems(String userId) {
		ApplicationContext context=new ClassPathXmlApplicationContext("cart.xml");
		userCarts=(HashMap<String, MenuItem>) context.getBean("cartlist");
		LOGGER.info("START");
		for(Map.Entry cart:userCarts.entrySet())
		{
			if(cart.getKey().toString().equals(userId))
			{
				list.add((MenuItem) cart.getValue());
			}
		}
		return list;
	}

	@Override
	public void removeCartItem(String userId, long menuItemId) {
		ApplicationContext context=new ClassPathXmlApplicationContext("cart.xml");
		userCarts=(HashMap<String, MenuItem>) context.getBean("cartlist");
		LOGGER.info("START");
		for(Map.Entry cart:userCarts.entrySet())
		{
			if(cart.getKey().toString().equals(userId))
			{
				MenuItem menuItem=(MenuItem) cart.getValue();
				if(menuItem.getId()==menuItemId)
				{
					userCarts.remove(userId,menuItemId);
				}
				LOGGER.info("deleted");
			}
		}
	}

}
