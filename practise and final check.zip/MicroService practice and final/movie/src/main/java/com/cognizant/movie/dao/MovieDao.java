package com.cognizant.movie.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.movie.model.Movie;

@Component
public interface MovieDao {

	public List<Movie> viewAllMovies();
	public List<Movie> editMovieDetails(Movie movie);
	public List<Movie> viewFavourites();
	public List<Movie> removeFavourites(String movieName);
}
