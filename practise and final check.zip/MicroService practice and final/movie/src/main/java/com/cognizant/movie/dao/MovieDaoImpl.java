package com.cognizant.movie.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cognizant.movie.model.Movie;

@Component
public class MovieDaoImpl implements MovieDao {
	
	private static List<Movie> movieList; 
	private ArrayList<Movie> favList=new ArrayList<Movie>();
	private static final Logger LOGGER=LoggerFactory.getLogger(MovieDaoImpl.class);
	public MovieDaoImpl()
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("movie.xml");
		movieList=(ArrayList<Movie>)context.getBean("movielist");
	}

	@Override
	public List<Movie> viewAllMovies() {
		return movieList;
	}

	@Override
	public List<Movie> editMovieDetails(Movie movie) {
		for(Movie list:movieList)
		{
			if(list.getName().equalsIgnoreCase(movie.getName()))
			{
				int index=movieList.indexOf(list);
				movieList.set(index, movie);
				LOGGER.info("Modified");
			}
		}
		return movieList;
	}

	@Override
	public List<Movie> viewFavourites() {
		for(Movie list:movieList)
		{
			if(list.isFavorite()==true)
			{
				favList.add(list);
			}
		}
		return favList;
	}

	@Override
	public List<Movie> removeFavourites(String movieName) {
		for(Movie list:movieList)
		{
			if(list.getName().equalsIgnoreCase(movieName))
			{
				int index=movieList.indexOf(list);
				list.setFavorite(false);
				movieList.remove(index);
				LOGGER.info("Modified");
			}
		}
		return movieList;
	}

}
