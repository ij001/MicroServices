package com.cognizant.movie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.movie.model.Movie;
import com.cognizant.movie.service.MovieService;

@RestController
@RequestMapping("/movies")
public class MovieController {
	
	@Autowired
	private MovieService movieService;
	
	@GetMapping("/view")
	public List<Movie> viewAllMovie()
	{
		return movieService.viewAllMovie();
	}
	
	@PutMapping("/edit")
	public List<Movie> editMovieDetails(@RequestBody Movie movie)
	{
		return movieService.editMovieDetails(movie);
	}
	
	@GetMapping("/fav")
	public List<Movie> viewFavourites()
	{
		return movieService.viewFavourites();
	}
	
	@DeleteMapping("/remove/{movieName}")
	public List<Movie> removeFavourites(@PathVariable String movieName)
	{
		return movieService.removeFavourites(movieName);
	}
}
