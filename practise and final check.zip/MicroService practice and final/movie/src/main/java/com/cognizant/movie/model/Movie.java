package com.cognizant.movie.model;

import lombok.Data;

public @Data class Movie {

	private String name,boxOffice,dateOfRelease,category;
	private boolean active,favorite;
}
