package com.cognizant.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.movie.dao.MovieDao;
import com.cognizant.movie.model.Movie;

@Service
public class MovieService {

	@Autowired
	private MovieDao movieDao;
	
	public List<Movie> viewAllMovie()
	{
		return movieDao.viewAllMovies();
	}
	
	public List<Movie> editMovieDetails(Movie movie)
	{
		return movieDao.editMovieDetails(movie);
	}
	
	public List<Movie> viewFavourites()
	{
		return movieDao.viewFavourites();
	}
	
	public List<Movie> removeFavourites(String movieName)
	{
		return movieDao.removeFavourites(movieName);
	}
}
