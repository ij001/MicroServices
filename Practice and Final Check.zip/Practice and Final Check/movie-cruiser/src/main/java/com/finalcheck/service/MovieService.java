package com.finalcheck.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.finalcheck.dao.MovieDao;
import com.finalcheck.model.Movie;

@Service
public class MovieService {
	
	@Autowired
	MovieDao dao;
	public ArrayList<Movie> getAllMovies()
	{
		return dao.getAllMovies();
	}
	/*public void addMovie(Movie movie)
	{
		dao.addMovie(movie);
	}*/
	public void editMovie(Movie movie)
	{
		dao.editMovie(movie);
	}
	public ArrayList<Movie> getCustomerMovies()
	{
		return dao.getCustomerMovies();
	}
	public void makeMovieFavorite(String title)
	{
		dao.makeMovieFavorite(title);
	}
	public ArrayList<String> getAllFavoriteMovies()
	{
		return dao.getAllFavoriteMovies();
	}
	public long favoriteCount()
	{
		return dao.favoriteCount();
	}
	public void deleteMovie(String title)
	{
		dao.deleteMovie(title);
	}
}
