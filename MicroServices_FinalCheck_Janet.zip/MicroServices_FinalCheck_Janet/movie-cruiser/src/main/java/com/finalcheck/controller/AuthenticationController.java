package com.finalcheck.controller;

import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.finalcheck.moviecruiser.MovieCruiserApplication;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
public class AuthenticationController {
	private static final Logger log = LoggerFactory.getLogger(MovieCruiserApplication.class);
	
	private static String getUser(String authHeader)
	{
		log.info("START getUser()");
		String str= new String(Base64.getDecoder().decode("dXNlcjpwd2Q="));
		String s[]= str.split(":");
		String res=s[0];
		log.debug(res);
		log.info("END getUser()");
		return res;
		
	}
	
	private static String generateJwt(String user)
	{
		JwtBuilder builder= Jwts.builder();
		builder.setSubject(user);
		builder.setIssuedAt(new Date());
		builder.setExpiration(new Date(new Date().getTime()+1200000));
		builder.signWith(SignatureAlgorithm.HS256, "secretkey");
		String token= builder.compact();
		return token;	
	}
	
	@GetMapping("/authenticate")
	public Map<String,String> authenticate(@RequestHeader("Authorization")String authHeader)
	{
		log.info("START authenticate");
		log.debug(authHeader);
		Map<String,String> map=new HashMap<String,String>();
		log.debug(getUser(authHeader));
		log.debug(generateJwt(getUser(authHeader)));
		map.put("token", "");
		map.put("token1", generateJwt(getUser(authHeader)));
		log.info("END authenticate");
		return map;
	}
	
}
