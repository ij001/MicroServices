package com.cognizant.Loan.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.Loan.Model.Loan;

@RestController
public class controller {
	
	@GetMapping("/loans/{number}")
	public Loan getLoan(@PathVariable String number)
	{
		return new Loan(number,"car",4000000,3258,18);
	}

}
