package com.cognizant.account.model;

public class Account {

	
	private int balance;
	private String type;
	private String accountNumber;
	
	public Account(String number, int i, String string) {
		setBalance(i);
		setType(string);
		setAccountNumber(number);
		
		
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
