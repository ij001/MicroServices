package com.cognizant.truyum.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.service.CartService;

@RestController
public class CartController {

	@Autowired
	private CartService cartService;
	
	@GetMapping("/carts")
	public HashMap<String,Cart> getCartItems()
	{
		return cartService.getCartItems();
	}
	
	@GetMapping("/carts/{userId}")
	public String getAllCartItems(@PathVariable String userId)
	{
		return cartService.getAllCartItems(userId);
		
	}
	
	@PostMapping("/carts/{userId}/{menuItemId}")
	public void addCartItem(@PathVariable String userId,@PathVariable String menuItemId)
	{
		cartService.addCartItem(userId, menuItemId);
	}
	
	@DeleteMapping("/carts/{userId}/{menuItemId}")
	public void deleteCartItem(@PathVariable String userId,@PathVariable String menuItemId)
	{
		cartService.deleteCartItem(userId, menuItemId);
	}
}
