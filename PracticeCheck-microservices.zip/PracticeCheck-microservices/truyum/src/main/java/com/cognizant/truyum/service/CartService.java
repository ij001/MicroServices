package com.cognizant.truyum.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dao.CartDaoCollectionImpl;
import com.cognizant.truyum.model.Cart;

@Service
public class CartService {

	@Autowired
	private CartDaoCollectionImpl cartDao;
	
	public HashMap<String, Cart> getCartItems()
	{
		return cartDao.getCartItems();
	}
	
	public String getAllCartItems(String userId)
	{
		return cartDao.getAllCartItems(userId);
	}
	
	public void addCartItem(String userId,String menuItemId)
	{
		cartDao.addCartItem(userId, menuItemId);
	}
	public void deleteCartItem(String userId,String menuItemId)
	{
		cartDao.deleteCartItem(userId, menuItemId);
	}
}
