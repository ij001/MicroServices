package com.cognizant.truyum.dao;

import java.util.HashMap;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.cognizant.truyum.model.Cart;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.service.MenuItemService;

@Component
public class CartDaoCollectionImpl implements CartDao {

	private HashMap<String,Cart> cartItems= new HashMap<String,Cart>();
	//private MenuItemService menuService;
	
	public HashMap<String,Cart> getCartItems()
	{
		return cartItems;
	}
	
	public String getAllCartItems(String userId)
	{
		Set<String> keys= cartItems.keySet();
		for(String key:keys)
		{
			if(key==userId)
			{	
				Cart obj=cartItems.get(key);
				System.out.println(obj.getMenuItemId());
				return obj.getMenuItemId();
			}
		}
		return null;
	}
	
	public void addCartItem(String userId ,String menuItemId)
	{
		Cart obj= new Cart();
		obj.setMenuItemId(menuItemId);
		cartItems.put(userId,obj);
		//System.out.println(cartItems);
	}
	
	public void deleteCartItem(String userId,String menuItemId)
	{
		cartItems.remove(userId);
	}
}
