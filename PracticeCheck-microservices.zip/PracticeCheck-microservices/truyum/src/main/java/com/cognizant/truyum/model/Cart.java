package com.cognizant.truyum.model;

import java.util.Date;

public class Cart {
	//private String userId;
	private String menuItemId;

	public Cart() {

	}

	public Cart(String menuItemId) {
		super();
		//this.userId = userId;
		this.menuItemId = menuItemId;
	}

	/*public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}*/

	public String getMenuItemId() {
		return menuItemId;
	}

	public void setMenuItemId(String menuItemId) {
		this.menuItemId = menuItemId;
	}

	@Override
	public String toString() {
		return "Cart [menuItemId=" + menuItemId + "]";
	}

}
