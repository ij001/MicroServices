package com.cognizant.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class Loan
{
	String loanId;
	String loanType;
	long loanAmount;
	int emi;
	int tenure;
}