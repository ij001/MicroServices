package com.cognizant.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class Account 
{
	int accNumber;
	String accountType;
	double balance;
}