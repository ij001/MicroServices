package com.cognizant.eurekadiscoveryserve;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaDiscoveryServeApplicationTests {

	@Test
	void contextLoads() {
	}

}
