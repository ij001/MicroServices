package com.cognizant.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Loan;

@RestController
public class LoanController {
	
	@GetMapping("/loans/{loanId}")
	public Loan getLoanDetails(@PathVariable String loanId) 
	{
		return new Loan(loanId,"car",400000,3258,18);
	}
}
