package com.cognizant.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Account;

@RestController
public class AccountController 
{
	@GetMapping("/accounts/{number}")
	public Account accDetails(@PathVariable int number) 
	{
		return new Account(number,"current",78456.50);
	}
}