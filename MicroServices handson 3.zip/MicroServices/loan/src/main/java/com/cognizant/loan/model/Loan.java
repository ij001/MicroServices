package com.cognizant.loan.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
public @Data class Loan {

	private String number,type;
	private int loan,emi,tenure;
}
